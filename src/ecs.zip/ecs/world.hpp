#pragma once

#include "entity_manager.hpp"
#include <vector>
#include <tuple>
#include <functional>

namespace opentower::ecs {

class QueryIterator {
public:
    QueryIterator() = default;

    QueryIterator(Archetype* archetype, EntityManager* manager, Entity::IdType arch_index)
        : archetype_(archetype), manager_(manager), arch_index_(arch_index) {
        if (archetype_ && arch_index_ < archetype_->entity_count()) {
            current_entity_ = archetype_->entities()[arch_index_];
        }
    }

    QueryIterator& operator++() {
        ++arch_index_;
        if (archetype_ && arch_index_ < archetype_->entity_count()) {
            current_entity_ = archetype_->entities()[arch_index_];
        } else {
            archetype_ = nullptr;
        }
        return *this;
    }

    Entity operator*() const { return current_entity_; }

    bool operator==(const QueryIterator& other) const {
        return archetype_ == other.archetype_ && arch_index_ == other.arch_index_;
    }

    bool operator!=(const QueryIterator& other) const {
        return !(*this == other);
    }

    template <typename T>
    T* get_component() const {
        if (!archetype_) return nullptr;
        return archetype_->get_component<T>(arch_index_);
    }

private:
    Archetype* archetype_ = nullptr;
    EntityManager* manager_ = nullptr;
    Entity::IdType arch_index_ = 0;
    Entity current_entity_ = Entity::null();
};

class Query {
public:
    Query() = default;

    void init(EntityManager& manager, BitSet required, BitSet excluded) {
        manager_ = &manager;
        required_ = required;
        excluded_ = excluded;
        rebuild();
    }

    void rebuild() {
        matching_archetypes_.clear();
        if (!manager_) return;

        const auto& archetypes = manager_->archetypes();
        for (auto& archetype : archetypes) {
            if (archetype.has_all(required_) && archetype.has_none(excluded_)) {
                matching_archetypes_.push_back(const_cast<Archetype*>(&archetype));
            }
        }
    }

    template <typename Func>
    void for_each(Func&& func) {
        for (Archetype* archetype : matching_archetypes_) {
            auto& entities = archetype->entities();
            for (Entity::IdType i = 0; i < static_cast<Entity::IdType>(entities.size()); ++i) {
                func(entities[i], archetype);
            }
        }
    }

    template <typename T, typename Func>
    void for_each_component(Func&& func) {
        ComponentTypeId::IdType type_id = ComponentTypeId::get<T>();

        for (Archetype* archetype : matching_archetypes_) {
            ComponentStorage* storage = archetype->get_component_storage(type_id);
            if (!storage) continue;

            auto& entities = archetype->entities();
            for (Entity::IdType i = 0; i < static_cast<Entity::IdType>(entities.size()); ++i) {
                T* component = storage->get_typed<T>(i);
                if (component) {
                    func(entities[i], *component);
                }
            }
        }
    }

    template <typename T1, typename T2, typename Func>
    void for_each_components(Func&& func) {
        ComponentTypeId::IdType type_id1 = ComponentTypeId::get<T1>();
        ComponentTypeId::IdType type_id2 = ComponentTypeId::get<T2>();

        for (Archetype* archetype : matching_archetypes_) {
            ComponentStorage* storage1 = archetype->get_component_storage(type_id1);
            ComponentStorage* storage2 = archetype->get_component_storage(type_id2);
            if (!storage1 || !storage2) continue;

            auto& entities = archetype->entities();
            for (Entity::IdType i = 0; i < static_cast<Entity::IdType>(entities.size()); ++i) {
                T1* c1 = storage1->get_typed<T1>(i);
                T2* c2 = storage2->get_typed<T2>(i);
                if (c1 && c2) {
                    func(entities[i], *c1, *c2);
                }
            }
        }
    }

    template <typename T1, typename T2, typename T3, typename Func>
    void for_each_components(Func&& func) {
        ComponentTypeId::IdType type_id1 = ComponentTypeId::get<T1>();
        ComponentTypeId::IdType type_id2 = ComponentTypeId::get<T2>();
        ComponentTypeId::IdType type_id3 = ComponentTypeId::get<T3>();

        for (Archetype* archetype : matching_archetypes_) {
            ComponentStorage* storage1 = archetype->get_component_storage(type_id1);
            ComponentStorage* storage2 = archetype->get_component_storage(type_id2);
            ComponentStorage* storage3 = archetype->get_component_storage(type_id3);
            if (!storage1 || !storage2 || !storage3) continue;

            auto& entities = archetype->entities();
            for (Entity::IdType i = 0; i < static_cast<Entity::IdType>(entities.size()); ++i) {
                T1* c1 = storage1->get_typed<T1>(i);
                T2* c2 = storage2->get_typed<T2>(i);
                T3* c3 = storage3->get_typed<T3>(i);
                if (c1 && c2 && c3) {
                    func(entities[i], *c1, *c2, *c3);
                }
            }
        }
    }

    const std::vector<Archetype*>& matching_archetypes() const {
        return matching_archetypes_;
    }

    size_t entity_count() const {
        size_t count = 0;
        for (const auto* archetype : matching_archetypes_) {
            count += archetype->entity_count();
        }
        return count;
    }

private:
    EntityManager* manager_ = nullptr;
    BitSet required_;
    BitSet excluded_;
    std::vector<Archetype*> matching_archetypes_;
};

class World {
public:
    World() = default;
    ~World() = default;

    Entity create_entity() {
        return entity_manager_.create_entity();
    }

    void destroy_entity(Entity entity) {
        if (!entity_manager_.is_valid(entity)) return;
        pending_destructions_.push_back(entity);
    }

    template <typename T>
    T* add_component(Entity entity) {
        T* component = entity_manager_.add_component<T>(entity);
        if (component) {
            mark_dirty();
        }
        return component;
    }

    template <typename T>
    T* set_component(Entity entity, const T& value) {
        T* component = entity_manager_.add_component<T>(entity);
        if (component) {
            *component = value;
            mark_dirty();
        }
        return component;
    }

    template <typename T>
    T* get_component(Entity entity) {
        return entity_manager_.get_component<T>(entity);
    }

    template <typename T>
    const T* get_component(Entity entity) const {
        return entity_manager_.get_component<T>(entity);
    }

    template <typename T>
    bool has_component(Entity entity) const {
        return entity_manager_.has_component<T>(entity);
    }

    template <typename T>
    void remove_component(Entity entity) {
        entity_manager_.remove_component<T>(entity);
        mark_dirty();
    }

    Query query() {
        return Query();
    }

    template <typename... Components>
    Query query_with() {
        Query q;
        BitSet required;
        BitSet excluded;

        (required.set(ComponentTypeId::get<Components>()), ...);

        q.init(entity_manager_, required, excluded);
        return q;
    }

    template <typename... Required, typename... Excluded>
    Query query_with_excluded() {
        Query q;
        BitSet required;
        BitSet excluded;

        (required.set(ComponentTypeId::get<Required>()), ...);
        (excluded.set(ComponentTypeId::get<Excluded>()), ...);

        q.init(entity_manager_, required, excluded);
        return q;
    }

    void update() {
        for (Entity entity : pending_destructions_) {
            entity_manager_.destroy_entity(entity);
        }
        pending_destructions_.clear();

        dirty_ = false;
    }

    EntityManager& entity_manager() { return entity_manager_; }
    const EntityManager& entity_manager() const { return entity_manager_; }
    ArchetypeGraph& archetype_graph() { return entity_manager_.graph(); }
    const ArchetypeGraph& archetype_graph() const { return entity_manager_.graph(); }

    size_t entity_count() const { return entity_manager_.entity_count(); }
    size_t archetype_count() const { return entity_manager_.archetype_count(); }

    bool is_dirty() const { return dirty_; }

private:
    void mark_dirty() { dirty_ = true; }

    EntityManager entity_manager_;
    std::vector<Entity> pending_destructions_;
    bool dirty_ = false;
};

} // namespace opentower::ecs
