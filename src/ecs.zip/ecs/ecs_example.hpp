#pragma once

#include "ecs_world_node.hpp"
#include <godot_cpp/classes/node2d.hpp>
#include <godot_cpp/variant/vector2.hpp>
#include <godot_cpp/classes/sprite2d.hpp>
#include <string>

namespace opentower::ecs::example {

// ============================================
// 1. 定义组件 (Components)
// ============================================

// 位置组件
struct Position {
    float x = 0.0f;
    float y = 0.0f;

    Position() = default;
    Position(float x, float y) : x(x), y(y) {}
};

// 速度组件
struct Velocity {
    float vx = 0.0f;
    float vy = 0.0f;

    Velocity() = default;
    Velocity(float vx, float vy) : vx(vx), vy(vy) {}
};

// 生命值组件
struct Health {
    float current = 100.0f;
    float max = 100.0f;

    Health() = default;
    Health(float current, float max) : current(current), max(max) {}

    bool is_alive() const { return current > 0; }
};

// 名称组件
struct Name {
    std::string value;

    Name() = default;
    Name(const std::string& name) : value(name) {}
};

// 渲染组件
struct Sprite {
    float width = 32.0f;
    float height = 32.0f;
    float rotation = 0.0f;
    float scale_x = 1.0f;
    float scale_y = 1.0f;
};

// ============================================
// 2. 创建示例系统 (Systems)
// ============================================

// 移动系统 - 更新位置
inline void create_movement_system(SystemRegistry& registry) {
    registry.add_named_system("Movement", [](World& world, double delta) {
        auto query = world.query_with<Position, Velocity>();

        query.for_each_components<Position, Velocity>(
            [](Entity entity, Position& pos, Velocity& vel) {
                pos.x += vel.vx * static_cast<float>(delta);
                pos.y += vel.vy * static_cast<float>(delta);
            }
        );
    });
}

// 重力系统 - 应用重力
inline void create_gravity_system(SystemRegistry& registry) {
    registry.add_named_system("Gravity", [](World& world, double delta) {
        constexpr float gravity = 980.0f;
        auto query = world.query_with<Velocity>();

        query.for_each_component<Velocity>(
            [gravity, delta](Entity entity, Velocity& vel) {
                vel.vy += gravity * static_cast<float>(delta);
            }
        );
    }, SystemPhase::PreUpdate);
}

// 生命值系统 - 处理死亡实体
inline void create_health_system(SystemRegistry& registry) {
    registry.add_named_system("Health", [](World& world, double delta) {
        auto query = world.query_with<Health>();

        query.for_each_component<Health>(
            [&world, delta](Entity entity, Health& health) {
                if (!health.is_alive()) {
                    // 标记销毁
                    world.destroy_entity(entity);
                }
            }
        );
    }, SystemPhase::PostUpdate);
}

// 边界检测系统
inline void create_boundary_system(SystemRegistry& registry, float world_width, float world_height) {
    registry.add_named_system("Boundary", [world_width, world_height](World& world, double delta) {
        auto query = world.query_with<Position>();

        query.for_each_component<Position>(
            [world_width, world_height](Entity entity, Position& pos) {
                // 简单的边界反弹
                if (pos.x < 0 || pos.x > world_width) {
                    if (auto* vel = world.get_component<Velocity>(entity)) {
                        vel->vx = -vel->vx;
                        pos.x = godot::Math::clamp(pos.x, 0.0f, world_width);
                    }
                }
                if (pos.y < 0 || pos.y > world_height) {
                    if (auto* vel = world.get_component<Velocity>(entity)) {
                        vel->vy = -vel->vy;
                        pos.y = godot::Math::clamp(pos.y, 0.0f, world_height);
                    }
                }
            }
        );
    });
}

// ============================================
// 3. 示例：创建游戏场景
// ============================================

// 在ECSWorldNode的_ready中调用此函数来初始化示例
inline void setup_example_world(ECSWorldNode* ecs_node) {
    if (!ecs_node || !ecs_node->get_world()) return;

    World* world = ecs_node->get_world();

    // 创建系统
    create_gravity_system(ecs_node->get_systems());
    create_movement_system(ecs_node->get_systems());
    create_boundary_system(ecs_node->get_systems(), 1920.0f, 1080.0f);
    create_health_system(ecs_node->get_systems());

    // 创建实体 - 玩家
    Entity player = world->create_entity();
    world->set_component<Position>(player, Position(960.0f, 540.0f));
    world->set_component<Velocity>(player, Velocity(100.0f, -200.0f));
    world->set_component<Health>(player, Health(100.0f, 100.0f));
    world->set_component<Name>(player, Name("Player"));
    world->set_component<Sprite>(player, Sprite());

    // 创建实体 - 敌人
    for (int i = 0; i < 10; ++i) {
        Entity enemy = world->create_entity();
        world->set_component<Position>(enemy, Position(
            100.0f + i * 150.0f,
            100.0f
        ));
        world->set_component<Velocity>(enemy, Velocity(
            50.0f,
            0.0f
        ));
        world->set_component<Health>(enemy, Health(50.0f, 50.0f));
        world->set_component<Name>(enemy, Name("Enemy_" + std::to_string(i)));
    }

    // 创建实体 - 只有位置的静态物体
    for (int i = 0; i < 5; ++i) {
        Entity obstacle = world->create_entity();
        world->set_component<Position>(obstacle, Position(
            200.0f + i * 300.0f,
            900.0f
        ));
        world->set_component<Name>(obstacle, Name("Obstacle_" + std::to_string(i)));
    }
}

// ============================================
// 4. 高级用法示例
// ============================================

// 示例：查询所有有位置和生命值的实体，但排除只有位置的实体
inline void example_complex_query(World& world) {
    // 查询所有有Position和Health的实体
    auto query = world.query_with<Position, Health>();

    query.for_each_components<Position, Health>(
        [](Entity entity, const Position& pos, Health& health) {
            // 处理同时具有位置和生命值的实体
            if (health.current < health.max * 0.5f) {
                // 生命值低于50%时的逻辑
            }
        }
    );
}

// 示例：实体动态添加/移除组件
inline void example_component_lifecycle(World& world) {
    Entity entity = world.create_entity();

    // 初始只有位置
    world.set_component<Position>(entity, Position(0, 0));

    // 添加速度 - 实体自动迁移到新的archetype
    Velocity* vel = world.add_component<Velocity>(entity);
    if (vel) {
        vel->vx = 100.0f;
        vel->vy = 0.0f;
    }

    // 移除速度 - 实体迁移回原来的archetype
    world.remove_component<Velocity>(entity);

    // 销毁实体
    world.destroy_entity(entity);
}

// ============================================
// 5. 性能优化提示
// ============================================

/*
 * 性能优化建议：
 *
 * 1. 组件设计：
 *    - 保持组件小而紧凑，尽量使用POD类型
 *    - 避免组件中包含虚函数或复杂的继承关系
 *    - 将经常一起访问的数据放在同一个组件中
 *
 * 2. 系统设计：
 *    - 将系统按执行阶段分组（PreUpdate/Update/PostUpdate）
 *    - 尽量减少系统间的依赖关系
 *    - 避免在系统执行期间创建/销毁实体
 *
 * 3. 查询优化：
 *    - 缓存Query对象，避免重复创建
 *    - 使用最具体的查询条件（更多的required组件 = 更少的实体）
 *    - 使用excluded来过滤不需要的实体
 *
 * 4. 内存布局：
 *    - Archetype ECS自动保证相同组件组合的实体内存连续
 *    - 这提供了最佳的CPU缓存命中率
 *    - 避免频繁添加/移除组件导致archetype碎片化
 */

} // namespace opentower::ecs::example
