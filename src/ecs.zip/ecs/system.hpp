#pragma once

#include "world.hpp"
#include <memory>
#include <vector>
#include <functional>
#include <string>
#include <algorithm>

namespace opentower::ecs {

// 系统执行阶段
enum class SystemPhase {
    PreUpdate,
    Update,
    PostUpdate,
    Count
};

// 系统基类
class System {
public:
    System() = default;
    virtual ~System() = default;

    virtual void execute(World& world, double delta) = 0;

    void set_name(const std::string& name) { name_ = name; }
    const std::string& name() const { return name_; }

    void set_enabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void set_phase(SystemPhase phase) { phase_ = phase; }
    SystemPhase phase() const { return phase_; }

private:
    std::string name_;
    bool enabled_ = true;
    SystemPhase phase_ = SystemPhase::Update;
};

// Lambda系统 - 使用lambda函数创建系统
template <typename Func>
class LambdaSystem : public System {
public:
    explicit LambdaSystem(Func&& func) : func_(std::forward<Func>(func)) {}

    void execute(World& world, double delta) override {
        func_(world, delta);
    }

private:
    Func func_;
};

// 创建lambda系统的辅助函数
template <typename Func>
std::unique_ptr<System> make_system(Func&& func) {
    return std::make_unique<LambdaSystem<Func>>(std::forward<Func>(func));
}

// 系统注册器
class SystemRegistry {
public:
    // 添加系统
    template <typename Func>
    System* add_system(Func&& func, SystemPhase phase = SystemPhase::Update) {
        auto system = make_system(std::forward<Func>(func));
        system->set_phase(phase);
        System* ptr = system.get();
        systems_.push_back(std::move(system));
        return ptr;
    }

    // 添加命名系统
    template <typename Func>
    System* add_named_system(const std::string& name, Func&& func, SystemPhase phase = SystemPhase::Update) {
        auto system = make_system(std::forward<Func>(func));
        system->set_name(name);
        system->set_phase(phase);
        System* ptr = system.get();
        systems_.push_back(std::move(system));
        return ptr;
    }

    // 执行所有系统
    void execute(World& world, double delta, SystemPhase phase) {
        for (auto& system : systems_) {
            if (system->enabled() && system->phase() == phase) {
                system->execute(world, delta);
            }
        }
    }

    // 执行所有阶段
    void execute_all(World& world, double delta) {
        for (int p = 0; p < static_cast<int>(SystemPhase::Count); ++p) {
            execute(world, delta, static_cast<SystemPhase>(p));
        }
    }

    // 获取系统
    template <typename T>
    T* get_system() {
        for (auto& system : systems_) {
            T* typed = dynamic_cast<T*>(system.get());
            if (typed) return typed;
        }
        return nullptr;
    }

    // 移除系统
    void remove_system(System* system) {
        systems_.erase(
            std::remove_if(systems_.begin(), systems_.end(),
                [system](const std::unique_ptr<System>& s) {
                    return s.get() == system;
                }),
            systems_.end()
        );
    }

    // 清空所有系统
    void clear() {
        systems_.clear();
    }

    // 访问器
    const std::vector<std::unique_ptr<System>>& systems() const { return systems_; }
    size_t system_count() const { return systems_.size(); }

private:
    std::vector<std::unique_ptr<System>> systems_;
};

} // namespace opentower::ecs
