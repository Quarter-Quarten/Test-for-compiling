# OpenTower Archetype ECS 架构

## 概述

这是一个基于 **Archetype** 模式的高性能 ECS (Entity-Component-System) 架构，专为 Godot GDExtension 项目设计。

## 原理

### 什么是 Archetype ECS？

Archetype ECS 是一种 ECS 实现方式，它将具有相同组件组合的实体分组存储在一起。这种设计带来了以下优势：

1. **内存连续性**: 相同类型的组件在内存中连续存储，极大提高 CPU 缓存命中率
2. **高效查询**: 通过 BitSet 签名快速过滤匹配的实体组
3. **迭代优化**: 遍历实体时只需要访问相关的内存块，避免缓存未命中

### 核心概念

```
World
  ├── EntityManager (管理实体生命周期)
  ├── ArchetypeGraph (管理原型图)
  │     └── Archetype (具有相同组件组合的实体组)
  │           ├── entities[] (实体列表)
  │           └── component_storages[] (按列存储的组件数据)
  └── SystemRegistry (管理系统执行)
        └── System[] (游戏逻辑系统)
```

### 工作流程

1. **创建实体**: 创建空实体，初始属于空 Archetype
2. **添加组件**: 实体迁移到具有新组件组合的 Archetype
3. **执行系统**: 系统通过 Query 找到匹配的 Archetypes，批量处理组件
4. **移除组件**: 实体迁移到缺少该组件的 Archetype
5. **销毁实体**: 从 Archetype 中移除，ID 回收到空闲列表

### 为什么高性能？

- **SoA (Structure of Arrays) 布局**: 组件按类型连续存储，而非每个实体一个对象
- **零虚函数调用**: 系统执行直接遍历内存块，无多态开销
- **BitSet 快速匹配**: O(1) 时间复杂度判断组件组合是否匹配查询
- **Swap-remove**: 实体删除 O(1)，保持数组紧凑

## 文件结构

```
src/ecs/
├── ecs_types.hpp      # 基础类型 (Entity, BitSet, SparseSet)
├── component.hpp      # 组件存储和元数据
├── archetype.hpp      # Archetype 原型和原型图
├── entity_manager.hpp # 实体管理器
├── world.hpp          # 世界和查询系统
├── system.hpp         # 系统基类和注册器
├── ecs_world_node.hpp # Godot 集成节点
└── ecs_example.hpp    # 使用示例
```

## 用法

### 1. 定义组件

组件是纯数据结构，不需要继承任何基类：

```cpp
#include "ecs/world.hpp"
using namespace opentower::ecs;

// 位置组件
struct Position {
    float x = 0.0f;
    float y = 0.0f;
};

// 速度组件
struct Velocity {
    float vx = 0.0f;
    float vy = 0.0f;
};

// 生命值组件
struct Health {
    float current = 100.0f;
    float max = 100.0f;
};
```

### 2. 创建 World 并添加系统

```cpp
// 在游戏节点中
class MyGame : public Node {
    GDCLASS(MyGame, Node);

    std::unique_ptr<World> world_;
    SystemRegistry systems_;

    void _ready() override {
        world_ = std::make_unique<World>();

        // 创建移动系统
        systems_.add_named_system("Movement", [](World& world, double delta) {
            auto query = world.query_with<Position, Velocity>();

            query.for_each_components<Position, Velocity>(
                [](Entity entity, Position& pos, Velocity& vel) {
                    pos.x += vel.vx * delta;
                    pos.y += vel.vy * delta;
                }
            );
        });

        // 创建重力系统 (在PreUpdate阶段执行)
        systems_.add_named_system("Gravity", [](World& world, double delta) {
            constexpr float gravity = 980.0f;
            auto query = world.query_with<Velocity>();

            query.for_each_component<Velocity>(
                [gravity, delta](Entity entity, Velocity& vel) {
                    vel.vy += gravity * delta;
                }
            );
        }, SystemPhase::PreUpdate);
    }

    void _process(double delta) override {
        systems_.execute_all(*world_, delta);
        world_->update();
    }
};
```

### 3. 创建实体和添加组件

```cpp
// 创建玩家实体
Entity player = world_->create_entity();

// 添加组件
world_->set_component<Position>(player, Position{960.0f, 540.0f});
world_->set_component<Velocity>(player, Velocity{100.0f, -200.0f});
world_->set_component<Health>(player, Health{100.0f, 100.0f});

// 或者使用指针方式
Position* pos = world_->add_component<Position>(player);
if (pos) {
    pos->x = 960.0f;
    pos->y = 540.0f;
}
```

### 4. 查询和迭代

```cpp
// 查询所有有位置和速度的实体
auto query = world_->query_with<Position, Velocity>();

query.for_each_components<Position, Velocity>(
    [](Entity entity, Position& pos, Velocity& vel) {
        // 处理实体
    }
);

// 查询带排除条件
auto query2 = world_->query_with<Position, Health>();
// 只处理有位置但没有生命值的实体（静态物体）
```

### 5. 使用 ECSWorldNode (Godot 集成)

在 Godot 场景中添加 ECSWorldNode 节点，然后在脚本中使用：

```gdscript
extends ECSWorldNode

func _ready():
    var entity = create_entity()
    print("Created entity: ", entity)

func _process(delta):
    print("Entity count: ", get_entity_count())
```

### 6. 动态组件操作

```cpp
// 添加组件 (实体自动迁移到匹配的 Archetype)
Velocity* vel = world_->add_component<Velocity>(entity);

// 移除组件 (实体迁移到新的 Archetype)
world_->remove_component<Velocity>(entity);

// 销毁实体
world_->destroy_entity(entity);
```

## 系统执行阶段

| 阶段 | 描述 | 用途 |
|------|------|------|
| PreUpdate | 在 Update 之前执行 | 物理预处理、输入处理 |
| Update | 主要执行阶段 | 游戏逻辑、AI、移动 |
| PostUpdate | 在 Update 之后执行 | 清理、死亡处理、渲染同步 |

## 性能优化建议

### 组件设计

- 使用 POD (Plain Old Data) 类型
- 保持组件小巧（最好 < 64 bytes）
- 将经常一起访问的数据合并到同一组件

### 系统设计

- 减少系统间的依赖
- 避免在系统执行时创建/销毁实体
- 使用延迟操作队列

### 查询优化

```cpp
// 好的做法：缓存查询对象
Query movement_query_;

void _ready() {
    movement_query_ = world_->query_with<Position, Velocity>();
}

void _process(double delta) {
    movement_query_.for_each_components<Position, Velocity>(...);
}
```

## 与传统 Godot 节点的对比

| 特性 | Godot Node | Archetype ECS |
|------|------------|---------------|
| 内存布局 | 分散（每个Node独立分配） | 连续（相同组件连续存储） |
| 缓存命中率 | 低（指针跳跃） | 高（顺序访问） |
| 适合场景 | UI、场景管理 | 大量实体、游戏逻辑 |
| 扩展性 | 继承树限制 | 组件组合无限扩展 |

## 注意事项

1. **组件必须是可默认构造的**（至少要有默认构造函数）
2. **避免在系统执行期间修改实体结构**（添加/移除组件）
3. **实体 ID 不保证连续**，使用 `Entity` 结构体而非直接用 ID
4. **World 不是线程安全的**，多线程需要外部同步

## 示例代码

完整示例请参考 `src/ecs/ecs_example.hpp` 文件。
