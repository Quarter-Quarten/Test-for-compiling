#pragma once

#include "ecs_types.hpp"
#include "archetype.hpp"
#include <vector>
#include <unordered_map>
#include <cstring>
#include <algorithm>

namespace opentower::ecs {

struct EntityRecord {
    Entity entity;
    Archetype* archetype = nullptr;
    Entity::IdType index_in_archetype = 0;
    bool alive = false;
};

class EntityManager {
public:
    EntityManager() {
        BitSet empty_sig;
        empty_archetype_ = graph_.add_archetype(empty_sig, {});
    }

    ~EntityManager() = default;

    Entity create_entity() {
        Entity entity;

        if (!free_list_.empty()) {
            entity.id = free_list_.back();
            free_list_.pop_back();
            entity.version = entity_versions_[entity.id];
        } else {
            entity.id = static_cast<Entity::IdType>(records_.size());
            entity.version = 0;
            entity_versions_.push_back(0);
            records_.emplace_back();
        }

        EntityRecord& record = records_[entity.id];
        record.entity = entity;
        record.archetype = empty_archetype_;
        record.index_in_archetype = empty_archetype_->add_entity(entity);
        record.alive = true;

        entity_count_++;
        return entity;
    }

    void destroy_entity(Entity entity) {
        if (!is_valid(entity)) return;

        EntityRecord& record = records_[entity.id];

        if (record.archetype) {
            record.archetype->remove_entity(record.index_in_archetype);
            record.archetype = nullptr;
        }

        record.alive = false;
        entity_versions_[entity.id]++;
        free_list_.push_back(entity.id);
        entity_count_--;
    }

    template <typename T>
    T* add_component(Entity entity) {
        if (!is_valid(entity)) return nullptr;

        EntityRecord& record = records_[entity.id];
        if (!record.archetype) return nullptr;

        ComponentTypeId::IdType type_id = ComponentTypeId::get<T>();

        if (record.archetype->signature().test(type_id)) {
            return record.archetype->get_component<T>(record.index_in_archetype);
        }

        Archetype* target = graph_.find_add_target(*record.archetype, type_id);
        if (!target) {
            BitSet new_signature = record.archetype->signature();
            new_signature.set(type_id);

            std::vector<ComponentTypeId::IdType> new_types = record.archetype->component_types();
            new_types.push_back(type_id);
            std::sort(new_types.begin(), new_types.end());

            target = graph_.add_archetype(new_signature, new_types);
            target->copy_storages_from(*record.archetype);
            target->ensure_storage<T>();
        } else {
            target->ensure_storage<T>();
        }

        migrate_entity(record, target);
        return target->get_component<T>(record.index_in_archetype);
    }

    template <typename T>
    void remove_component(Entity entity) {
        if (!is_valid(entity)) return;

        EntityRecord& record = records_[entity.id];
        if (!record.archetype) return;

        ComponentTypeId::IdType type_id = ComponentTypeId::get<T>();

        if (!record.archetype->signature().test(type_id)) return;

        Archetype* target = graph_.find_remove_target(*record.archetype, type_id);
        if (!target) return;

        migrate_entity(record, target);
    }

    template <typename T>
    T* get_component(Entity entity) {
        if (!is_valid(entity)) return nullptr;

        const EntityRecord& record = records_[entity.id];
        if (!record.archetype) return nullptr;

        return record.archetype->get_component<T>(record.index_in_archetype);
    }

    template <typename T>
    const T* get_component(Entity entity) const {
        if (!is_valid(entity)) return nullptr;

        const EntityRecord& record = records_[entity.id];
        if (!record.archetype) return nullptr;

        return record.archetype->get_component<T>(record.index_in_archetype);
    }

    template <typename T>
    bool has_component(Entity entity) const {
        if (!is_valid(entity)) return false;

        const EntityRecord& record = records_[entity.id];
        if (!record.archetype) return false;

        return record.archetype->signature().test(ComponentTypeId::get<T>());
    }

    bool is_valid(Entity entity) const {
        if (entity.id >= records_.size()) return false;
        const EntityRecord& record = records_[entity.id];
        return record.alive && record.entity.version == entity.version;
    }

    const EntityRecord* get_record(Entity entity) const {
        if (!is_valid(entity)) return nullptr;
        return &records_[entity.id];
    }

    ArchetypeGraph& graph() { return graph_; }
    const ArchetypeGraph& graph() const { return graph_; }

    size_t entity_count() const { return entity_count_; }
    size_t archetype_count() const { return graph_.archetype_count(); }

    const std::vector<Archetype>& archetypes() const { return graph_.archetypes(); }
    std::vector<Archetype>& archetypes() { return graph_.archetypes(); }

private:
    void migrate_entity(EntityRecord& record, Archetype* target) {
        if (record.archetype == target) return;

        Archetype* source = record.archetype;
        Entity entity = record.entity;
        Entity::IdType source_index = record.index_in_archetype;

        std::vector<std::pair<ComponentTypeId::IdType, std::vector<uint8_t>>> saved_data;
        for (ComponentTypeId::IdType type_id : source->component_types()) {
            if (!target->signature().test(type_id)) continue;

            ComponentStorage* source_storage = source->get_component_storage(type_id);
            if (!source_storage) continue;

            const ComponentMeta* meta = source_storage->meta();
            if (!meta) continue;

            uint8_t* src_data = static_cast<uint8_t*>(source_storage->get(source_index));
            std::vector<uint8_t> data(meta->size);

            if (meta->copier) {
                meta->copier(data.data(), src_data, 1);
            } else {
                std::memcpy(data.data(), src_data, meta->size);
            }

            saved_data.emplace_back(type_id, std::move(data));
        }

        source->remove_entity(source_index);

        Entity::IdType target_index = target->add_entity(entity);
        record.archetype = target;
        record.index_in_archetype = target_index;

        for (auto& [type_id, data] : saved_data) {
            ComponentStorage* target_storage = target->get_component_storage(type_id);
            if (!target_storage) continue;

            const ComponentMeta* meta = target_storage->meta();
            if (!meta) continue;

            void* dst = target_storage->get(target_index);
            if (meta->destructor) {
                meta->destructor(dst, 1);
            }
            if (meta->copier) {
                meta->copier(dst, data.data(), 1);
            } else {
                std::memcpy(dst, data.data(), data.size());
            }
        }
    }

    std::vector<EntityRecord> records_;
    std::vector<Entity::VersionType> entity_versions_;
    std::vector<Entity::IdType> free_list_;
    ArchetypeGraph graph_;
    Archetype* empty_archetype_ = nullptr;
    size_t entity_count_ = 0;
};

} // namespace opentower::ecs
