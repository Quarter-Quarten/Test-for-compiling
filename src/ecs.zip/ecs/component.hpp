#pragma once

#include "ecs_types.hpp"
#include <cstring>
#include <memory>
#include <vector>
#include <functional>
#include <type_traits>
#include <algorithm>
#include <unordered_map>

namespace opentower::ecs {

// 组件存储策略
enum class ComponentStorageType {
    Trivial,    // 平凡类型 (memcpy safe)
    NonTrivial  // 非平凡类型 (需要构造/析构)
};

// 组件元数据
struct ComponentMeta {
    ComponentTypeId::IdType type_id = 0;
    size_t size = 0;
    ComponentStorageType storage_type = ComponentStorageType::Trivial;
    std::function<void(void*, size_t)> constructor;
    std::function<void(void*, size_t)> destructor;
    std::function<void(void*, const void*, size_t)> copier;
    std::function<void(void*, void*, size_t)> mover;

    template <typename T>
    static ComponentMeta create() {
        ComponentMeta meta;
        meta.type_id = ComponentTypeId::get<T>();
        meta.size = sizeof(T);
        meta.storage_type = std::is_trivially_copyable_v<T> ?
            ComponentStorageType::Trivial : ComponentStorageType::NonTrivial;

        if constexpr (std::is_default_constructible_v<T>) {
            meta.constructor = [](void* ptr, size_t count) {
                T* typed = static_cast<T*>(ptr);
                for (size_t i = 0; i < count; ++i) {
                    new (&typed[i]) T();
                }
            };
        }

        if constexpr (!std::is_trivially_destructible_v<T>) {
            meta.destructor = [](void* ptr, size_t count) {
                T* typed = static_cast<T*>(ptr);
                for (size_t i = 0; i < count; ++i) {
                    typed[i].~T();
                }
            };
        }

        if constexpr (!std::is_trivially_copyable_v<T>) {
            meta.copier = [](void* dst, const void* src, size_t count) {
                const T* typed_src = static_cast<const T*>(src);
                T* typed_dst = static_cast<T*>(dst);
                for (size_t i = 0; i < count; ++i) {
                    new (&typed_dst[i]) T(typed_src[i]);
                }
            };
        }

        if constexpr (!std::is_trivially_move_constructible_v<T>) {
            meta.mover = [](void* dst, void* src, size_t count) {
                T* typed_src = static_cast<T*>(src);
                T* typed_dst = static_cast<T*>(dst);
                for (size_t i = 0; i < count; ++i) {
                    new (&typed_dst[i]) T(std::move(typed_src[i]));
                    typed_src[i].~T();
                }
            };
        }

        return meta;
    }
};

// 组件存储 - 连续的内存块
class ComponentStorage {
public:
    ComponentStorage() = default;
    ~ComponentStorage() { clear(); }

    ComponentStorage(ComponentStorage&& other) noexcept = default;
    ComponentStorage& operator=(ComponentStorage&& other) noexcept = default;

    ComponentStorage(const ComponentStorage&) = delete;
    ComponentStorage& operator=(const ComponentStorage&) = delete;

    void init(const ComponentMeta& meta, size_t capacity = 64) {
        clear();
        meta_ = meta;
        initialized_ = true;
        capacity_ = capacity;
        data_ = static_cast<uint8_t*>(::operator new(meta_.size * capacity_));
    }

    void clear() {
        if (data_) {
            if (initialized_ && meta_.destructor && size_ > 0) {
                meta_.destructor(data_, size_);
            }
            ::operator delete(data_);
            data_ = nullptr;
        }
        size_ = 0;
        capacity_ = 0;
        initialized_ = false;
    }

    bool is_initialized() const { return initialized_; }

    void* get(size_t index) const {
        return data_ + index * meta_.size;
    }

    template <typename T>
    T* get_typed(size_t index) const {
        return static_cast<T*>(get(index));
    }

    size_t add() {
        if (!initialized_) return 0;

        if (size_ >= capacity_) {
            grow();
        }

        void* ptr = get(size_);
        if (meta_.constructor) {
            meta_.constructor(ptr, 1);
        }

        return size_++;
    }

    void remove(size_t index) {
        if (!initialized_ || index >= size_) return;

        if (index != size_ - 1) {
            if (meta_.destructor) {
                meta_.destructor(get(index), 1);
            }
            if (meta_.copier) {
                meta_.copier(get(index), get(size_ - 1), 1);
            } else {
                std::memmove(get(index), get(size_ - 1), meta_.size);
            }
        } else if (meta_.destructor) {
            meta_.destructor(get(index), 1);
        }

        --size_;
    }

    void remove_unordered(size_t index, size_t last_index) {
        if (!initialized_ || index >= size_ || last_index >= size_) return;

        if (meta_.destructor) {
            meta_.destructor(get(index), 1);
        }
        if (meta_.copier) {
            meta_.copier(get(index), get(last_index), 1);
        } else {
            std::memmove(get(index), get(last_index), meta_.size);
        }
    }

    size_t size() const { return size_; }
    size_t capacity() const { return capacity_; }
    const ComponentMeta* meta() const { return initialized_ ? &meta_ : nullptr; }
    uint8_t* data() const { return data_; }

private:
    void grow() {
        size_t new_capacity = capacity_ == 0 ? 64 : capacity_ * 2;
        uint8_t* new_data = static_cast<uint8_t*>(::operator new(meta_.size * new_capacity));

        if (meta_.copier) {
            meta_.copier(new_data, data_, size_);
        } else if (size_ > 0) {
            std::memcpy(new_data, data_, meta_.size * size_);
        }

        if (meta_.constructor && size_ < new_capacity) {
            meta_.constructor(get_at(new_data, size_), new_capacity - size_);
        }

        if (meta_.destructor) {
            meta_.destructor(data_, size_);
        }
        ::operator delete(data_);

        data_ = new_data;
        capacity_ = new_capacity;
    }

    void* get_at(uint8_t* base, size_t index) const {
        return base + index * meta_.size;
    }

    ComponentMeta meta_;
    uint8_t* data_ = nullptr;
    size_t size_ = 0;
    size_t capacity_ = 0;
    bool initialized_ = false;
};

// 组件存储池 - 管理多个组件类型的存储
class ComponentPool {
public:
    template <typename T>
    void register_component() {
        ComponentTypeId::IdType id = ComponentTypeId::get<T>();
        if (storages_.find(id) == storages_.end()) {
            ComponentStorage storage;
            storage.init(ComponentMeta::create<T>());
            storages_[id] = std::move(storage);
        }
    }

    ComponentStorage* get_storage(ComponentTypeId::IdType id) {
        auto it = storages_.find(id);
        if (it != storages_.end()) {
            return &it->second;
        }
        return nullptr;
    }

    const ComponentStorage* get_storage(ComponentTypeId::IdType id) const {
        auto it = storages_.find(id);
        if (it != storages_.end()) {
            return &it->second;
        }
        return nullptr;
    }

    bool has_component(ComponentTypeId::IdType id) const {
        return storages_.find(id) != storages_.end();
    }

private:
    std::unordered_map<ComponentTypeId::IdType, ComponentStorage> storages_;
};

} // namespace opentower::ecs
