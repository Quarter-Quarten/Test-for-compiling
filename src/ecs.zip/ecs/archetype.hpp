#pragma once

#include "ecs_types.hpp"
#include "component.hpp"
#include <vector>
#include <unordered_map>
#include <memory>
#include <algorithm>
#include <functional>

namespace opentower::ecs {

// Archetype - 具有相同组件组合的实体组
class Archetype {
public:
    Archetype() = default;

    Archetype(BitSet signature, std::vector<ComponentTypeId::IdType> component_types)
        : signature_(signature), component_types_(std::move(component_types)) {
        build_column_map();
    }

    ~Archetype() = default;

    Archetype(Archetype&& other) noexcept = default;
    Archetype& operator=(Archetype&& other) noexcept = default;

    Archetype(const Archetype&) = delete;
    Archetype& operator=(const Archetype&) = delete;

    Entity::IdType add_entity(Entity entity) {
        Entity::IdType index = static_cast<Entity::IdType>(entities_.size());
        entities_.push_back(entity);
        entity_to_index_[entity.id] = index;

        for (auto& storage : component_storages_) {
            if (storage.is_initialized()) {
                storage.add();
            }
        }

        return index;
    }

    void remove_entity(Entity::IdType index) {
        if (index >= entities_.size()) return;

        Entity entity = entities_[index];
        entity_to_index_.erase(entity.id);

        Entity::IdType last_index = static_cast<Entity::IdType>(entities_.size()) - 1;

        for (auto& storage : component_storages_) {
            if (storage.is_initialized()) {
                storage.remove(index);
            }
        }

        if (index != last_index) {
            entities_[index] = entities_[last_index];
            entity_to_index_[entities_[index].id] = index;
        }

        entities_.pop_back();
    }

    Entity::IdType get_entity_index(Entity::IdType entity_id) const {
        auto it = entity_to_index_.find(entity_id);
        if (it != entity_to_index_.end()) {
            return it->second;
        }
        return static_cast<Entity::IdType>(-1);
    }

    ComponentStorage* get_component_storage(ComponentTypeId::IdType type_id) {
        auto it = column_map_.find(type_id);
        if (it != column_map_.end() && it->second < component_storages_.size()) {
            ComponentStorage* storage = &component_storages_[it->second];
            if (storage->is_initialized()) {
                return storage;
            }
        }
        return nullptr;
    }

    const ComponentStorage* get_component_storage(ComponentTypeId::IdType type_id) const {
        auto it = column_map_.find(type_id);
        if (it != column_map_.end() && it->second < component_storages_.size()) {
            const ComponentStorage* storage = &component_storages_[it->second];
            if (storage->is_initialized()) {
                return storage;
            }
        }
        return nullptr;
    }

    template <typename T>
    T* get_component(Entity::IdType index) {
        ComponentTypeId::IdType type_id = ComponentTypeId::get<T>();
        ComponentStorage* storage = get_component_storage(type_id);
        if (storage) {
            return storage->get_typed<T>(index);
        }
        return nullptr;
    }

    template <typename T>
    const T* get_component(Entity::IdType index) const {
        ComponentTypeId::IdType type_id = ComponentTypeId::get<T>();
        const ComponentStorage* storage = get_component_storage(type_id);
        if (storage) {
            return storage->get_typed<T>(index);
        }
        return nullptr;
    }

    void ensure_storage(ComponentTypeId::IdType type_id, const ComponentMeta& meta) {
        auto it = column_map_.find(type_id);
        if (it == column_map_.end()) {
            size_t storage_index = component_storages_.size();
            component_storages_.emplace_back();
            component_storages_.back().init(meta);
            column_map_[type_id] = storage_index;
            return;
        }

        size_t index = it->second;
        if (component_storages_.size() <= index) {
            component_storages_.resize(index + 1);
        }
        if (!component_storages_[index].is_initialized()) {
            component_storages_[index].init(meta);
        }
    }

    template <typename T>
    void ensure_storage() {
        ensure_storage(ComponentTypeId::get<T>(), ComponentMeta::create<T>());
    }

    void copy_storages_from(const Archetype& source) {
        for (ComponentTypeId::IdType type_id : component_types_) {
            const ComponentStorage* source_storage = source.get_component_storage(type_id);
            if (source_storage && source_storage->meta()) {
                ensure_storage(type_id, *source_storage->meta());
            }
        }
    }

    const BitSet& signature() const { return signature_; }
    const std::vector<ComponentTypeId::IdType>& component_types() const { return component_types_; }
    const std::vector<Entity>& entities() const { return entities_; }
    size_t entity_count() const { return entities_.size(); }
    size_t storage_count() const { return component_storages_.size(); }
    const std::vector<ComponentStorage>& component_storages() const { return component_storages_; }
    std::vector<ComponentStorage>& component_storages() { return component_storages_; }

    bool matches(const BitSet& required, const BitSet& excluded) const {
        return has_all(required) && has_none(excluded);
    }

    bool has_signature(const BitSet& sig) const {
        return signature_ == sig;
    }

    bool has_all(const BitSet& required) const {
        BitSet intersection = signature_ & required;
        return intersection == required;
    }

    bool has_none(const BitSet& excluded) const {
        BitSet intersection = signature_ & excluded;
        return intersection.count() == 0;
    }

private:
    void build_column_map() {
        column_map_.clear();
        for (size_t i = 0; i < component_types_.size(); ++i) {
            column_map_[component_types_[i]] = i;
        }
    }

    BitSet signature_;
    std::vector<ComponentTypeId::IdType> component_types_;
    std::vector<Entity> entities_;
    std::vector<ComponentStorage> component_storages_;
    std::unordered_map<ComponentTypeId::IdType, size_t> column_map_;
    std::unordered_map<Entity::IdType, Entity::IdType> entity_to_index_;
};

// Archetype图 - 管理archetype之间的转换关系
class ArchetypeGraph {
public:
    Archetype* add_archetype(BitSet signature, std::vector<ComponentTypeId::IdType> types) {
        archetypes_.emplace_back(std::move(signature), std::move(types));
        return &archetypes_.back();
    }

    Archetype* get_or_create_archetype(BitSet signature, std::vector<ComponentTypeId::IdType> types) {
        for (auto& archetype : archetypes_) {
            if (archetype.has_signature(signature)) {
                return &archetype;
            }
        }
        return add_archetype(std::move(signature), std::move(types));
    }

    void find_matching(const BitSet& required, const BitSet& excluded,
                       std::vector<Archetype*>& out) const {
        out.clear();
        for (Archetype& archetype : const_cast<std::vector<Archetype>&>(archetypes_)) {
            if (archetype.has_all(required) && archetype.has_none(excluded)) {
                out.push_back(&archetype);
            }
        }
    }

    Archetype* find_add_target(const Archetype& source, ComponentTypeId::IdType component_id) const {
        BitSet new_signature = source.signature();
        new_signature.set(component_id);

        for (Archetype& archetype : const_cast<std::vector<Archetype>&>(archetypes_)) {
            if (archetype.has_signature(new_signature)) {
                return &archetype;
            }
        }
        return nullptr;
    }

    Archetype* find_remove_target(const Archetype& source, ComponentTypeId::IdType component_id) const {
        if (!source.signature().test(component_id)) {
            return nullptr;
        }

        BitSet new_signature = source.signature();
        new_signature.reset(component_id);

        for (Archetype& archetype : const_cast<std::vector<Archetype>&>(archetypes_)) {
            if (archetype.has_signature(new_signature)) {
                return &archetype;
            }
        }
        return nullptr;
    }

    const std::vector<Archetype>& archetypes() const { return archetypes_; }
    std::vector<Archetype>& archetypes() { return archetypes_; }
    size_t archetype_count() const { return archetypes_.size(); }

private:
    std::vector<Archetype> archetypes_;
};

} // namespace opentower::ecs
