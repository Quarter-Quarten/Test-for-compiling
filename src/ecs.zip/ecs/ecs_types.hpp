#pragma once

#include <cstddef>
#include <cstdint>
#include <type_traits>
#include <typeindex>
#include <unordered_map>
#include <vector>
#include <string>

namespace opentower::ecs {

// 组件类型ID生成器
class ComponentTypeId {
public:
    using IdType = uint32_t;

    template <typename T>
    static IdType get() {
        static IdType id = next_id();
        return id;
    }

    static IdType register_type(const std::type_info& info, size_t size) {
        IdType id = next_id();
        type_info_map()[id] = &info;
        type_size_map()[id] = size;
        return id;
    }

    static const std::type_info& get_type_info(IdType id) {
        auto it = type_info_map().find(id);
        if (it != type_info_map().end()) {
            return *it->second;
        }
        return typeid(void);
    }

    static size_t get_type_size(IdType id) {
        auto it = type_size_map().find(id);
        if (it != type_size_map().end()) {
            return it->second;
        }
        return 0;
    }

    static uint32_t get_max_id() {
        return current_id();
    }

private:
    static IdType next_id() {
        static IdType id = 0;
        current_id() = id;
        return id++;
    }

    static IdType& current_id() {
        static IdType id = 0;
        return id;
    }

    static std::unordered_map<IdType, const std::type_info*>& type_info_map() {
        static std::unordered_map<IdType, const std::type_info*> map;
        return map;
    }

    static std::unordered_map<IdType, size_t>& type_size_map() {
        static std::unordered_map<IdType, size_t> map;
        return map;
    }
};

// 实体ID
struct Entity {
    using IdType = uint32_t;
    using VersionType = uint32_t;

    IdType id = 0;
    VersionType version = 0;

    constexpr bool operator==(const Entity& other) const {
        return id == other.id;
    }

    constexpr bool operator!=(const Entity& other) const {
        return id != other.id;
    }

    constexpr bool operator<(const Entity& other) const {
        return id < other.id;
    }

    static constexpr Entity null() { return {UINT32_MAX, 0}; }
    constexpr bool is_null() const { return id == UINT32_MAX; }
};

// 稀疏集合 - 用于实体到索引的快速映射
template <typename T>
class SparseSet {
public:
    T get(uint32_t entity) const {
        return sparse_[entity];
    }

    void set(uint32_t entity, T value) {
        if (entity >= sparse_.size()) {
            sparse_.resize(entity + 1, T{});
        }
        sparse_[entity] = value;
    }

    bool has(uint32_t entity) const {
        return entity < sparse_.size() && sparse_[entity] != T{};
    }

    void remove(uint32_t entity) {
        if (entity < sparse_.size()) {
            sparse_[entity] = T{};
        }
    }

    void clear() {
        sparse_.clear();
    }

    size_t size() const { return sparse_.size(); }

private:
    std::vector<T> sparse_;
};

// 位集合 - 用于组件签名
class BitSet {
public:
    static constexpr size_t MAX_COMPONENTS = 256;

    BitSet() = default;

    void set(ComponentTypeId::IdType id) {
        if (id < MAX_COMPONENTS) {
            bits_[id / 64] |= (1ULL << (id % 64));
        }
    }

    void reset(ComponentTypeId::IdType id) {
        if (id < MAX_COMPONENTS) {
            bits_[id / 64] &= ~(1ULL << (id % 64));
        }
    }

    bool test(ComponentTypeId::IdType id) const {
        if (id >= MAX_COMPONENTS) return false;
        return (bits_[id / 64] & (1ULL << (id % 64))) != 0;
    }

    bool is_subset_of(const BitSet& other) const {
        for (size_t i = 0; i < 4; ++i) {
            if ((bits_[i] & ~other.bits_[i]) != 0) {
                return false;
            }
        }
        return true;
    }

    bool operator==(const BitSet& other) const {
        for (size_t i = 0; i < 4; ++i) {
            if (bits_[i] != other.bits_[i]) {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const BitSet& other) const {
        return !(*this == other);
    }

    bool operator<(const BitSet& other) const {
        for (size_t i = 0; i < 4; ++i) {
            if (bits_[i] < other.bits_[i]) return true;
            if (bits_[i] > other.bits_[i]) return false;
        }
        return false;
    }

    size_t count() const {
        size_t count = 0;
        for (size_t i = 0; i < 4; ++i) {
            count += popcount(bits_[i]);
        }
        return count;
    }

    BitSet operator|(const BitSet& other) const {
        BitSet result;
        for (size_t i = 0; i < 4; ++i) {
            result.bits_[i] = bits_[i] | other.bits_[i];
        }
        return result;
    }

    BitSet operator&(const BitSet& other) const {
        BitSet result;
        for (size_t i = 0; i < 4; ++i) {
            result.bits_[i] = bits_[i] & other.bits_[i];
        }
        return result;
    }

private:
    static size_t popcount(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
        return static_cast<size_t>(__builtin_popcountll(x));
#else
        x -= (x >> 1) & 0x5555555555555555ULL;
        x = (x & 0x3333333333333333ULL) + ((x >> 2) & 0x3333333333333333ULL);
        x = (x + (x >> 4)) & 0x0F0F0F0F0F0F0F0FULL;
        x += x >> 8;
        x += x >> 16;
        x += x >> 32;
        return static_cast<size_t>(x & 0x7F);
#endif
    }

    uint64_t bits_[4] = {0, 0, 0, 0};
};

} // namespace opentower::ecs

// Hash specialization for Entity
namespace std {
    template<>
    struct hash<opentower::ecs::Entity> {
        size_t operator()(const opentower::ecs::Entity& e) const {
            return hash<opentower::ecs::Entity::IdType>()(e.id);
        }
    };
}
