#pragma once

#include "system.hpp"
#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/variant/utility_functions.hpp>
#include <cstdint>

namespace opentower::ecs {

// ECSWorldNode - Godot节点，作为ECS世界的容器
class ECSWorldNode : public godot::Node {
    GDCLASS(ECSWorldNode, godot::Node);

public:
    ECSWorldNode() = default;
    ~ECSWorldNode() override = default;

    void _ready() override {
        world_ = std::make_unique<World>();
    }

    void _process(double delta) override {
        if (!world_) return;

        // 执行所有系统
        systems_.execute_all(*world_, delta);

        // 更新world（处理延迟操作）
        world_->update();
    }

    void _exit_tree() override {
        systems_.clear();
        world_.reset();
    }

    // 访问World
    World* get_world() { return world_.get(); }
    const World* get_world() const { return world_.get(); }

    // 创建实体
    godot::Dictionary create_entity() {
        if (!world_) return {};

        Entity entity = world_->create_entity();
        godot::Dictionary result;
        result["id"] = static_cast<int64_t>(entity.id);
        result["version"] = static_cast<int64_t>(entity.version);
        return result;
    }

    // 销毁实体
    void destroy_entity(int64_t id, int64_t version) {
        if (!world_) return;

        Entity entity;
        entity.id = static_cast<Entity::IdType>(id);
        entity.version = static_cast<Entity::VersionType>(version);
        world_->destroy_entity(entity);
    }

    // 获取实体数量
    int64_t get_entity_count() const {
        if (!world_) return 0;
        return static_cast<int64_t>(world_->entity_count());
    }

    // 获取archetype数量
    int64_t get_archetype_count() const {
        if (!world_) return 0;
        return static_cast<int64_t>(world_->archetype_count());
    }

    // 添加系统
    template <typename Func>
    System* add_system(Func&& func, SystemPhase phase = SystemPhase::Update) {
        return systems_.add_system(std::forward<Func>(func), phase);
    }

    // 获取系统注册器
    SystemRegistry& get_systems() { return systems_; }
    const SystemRegistry& get_systems() const { return systems_; }

    static void _bind_methods() {
        using namespace godot;
        ClassDB::bind_method(D_METHOD("create_entity"), &ECSWorldNode::create_entity);
        ClassDB::bind_method(D_METHOD("destroy_entity", "id", "version"), &ECSWorldNode::destroy_entity);
        ClassDB::bind_method(D_METHOD("get_entity_count"), &ECSWorldNode::get_entity_count);
        ClassDB::bind_method(D_METHOD("get_archetype_count"), &ECSWorldNode::get_archetype_count);
    }

private:
    std::unique_ptr<World> world_;
    SystemRegistry systems_;
};

} // namespace opentower::ecs
